import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/site";
import { articles } from "@/lib/insights";
import { deliverables } from "@/lib/deliverables";
import { aperturePractices } from "@/lib/content";
import { landingPages } from "@/lib/landing";
import { industries } from "@/lib/industries";
import { componentHref } from "@/lib/componentLinks";

/**
 * XML sitemap (served at /sitemap.xml). Generated from the same content sources
 * the pages render from, so it never drifts out of sync.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const url = (path: string) => new URL(path, siteConfig.url).toString();

  type Route = {
    path: string;
    priority: number;
    changeFrequency: MetadataRoute.Sitemap[number]["changeFrequency"];
    /** Set only where a real revision date is known. Otherwise the build time. */
    lastModified?: Date;
  };

  const staticRoutes: Route[] = [
    { path: "/", priority: 1.0, changeFrequency: "weekly" },
    { path: "/the-aperture-method", priority: 0.9, changeFrequency: "monthly" },
    { path: "/what-we-do", priority: 0.9, changeFrequency: "monthly" },
    { path: "/who-its-for", priority: 0.9, changeFrequency: "monthly" },
    { path: "/the-intelligence-gap", priority: 0.8, changeFrequency: "monthly" },
    { path: "/industries", priority: 0.8, changeFrequency: "monthly" },

    { path: "/what-you-get", priority: 0.9, changeFrequency: "monthly" },
    { path: "/snapshot", priority: 0.8, changeFrequency: "monthly" },
    { path: "/deliverables", priority: 0.9, changeFrequency: "monthly" },
    { path: "/ai", priority: 0.9, changeFrequency: "monthly" },
    { path: "/case-studies", priority: 0.7, changeFrequency: "monthly" },
    { path: "/case-studies/lumina-medical-aesthetics", priority: 0.8, changeFrequency: "monthly" },
    { path: "/method-lab/financial-analysis-workbench", priority: 0.7, changeFrequency: "monthly" },
    { path: "/method-lab/coursework", priority: 0.5, changeFrequency: "monthly" },
    { path: "/insights", priority: 0.8, changeFrequency: "weekly" },
    { path: "/working-together", priority: 0.8, changeFrequency: "monthly" },
    { path: "/pricing", priority: 0.9, changeFrequency: "monthly" },
    { path: "/about", priority: 0.7, changeFrequency: "monthly" },
    { path: "/what-we-believe", priority: 0.7, changeFrequency: "monthly" },
    { path: "/book", priority: 0.6, changeFrequency: "monthly" },
    { path: "/founder", priority: 0.6, changeFrequency: "yearly" },
    { path: "/clarity-check", priority: 0.9, changeFrequency: "monthly" },
    { path: "/buying-a-business", priority: 0.7, changeFrequency: "monthly" },
    { path: "/contact", priority: 0.8, changeFrequency: "yearly" },
    { path: "/privacy", priority: 0.3, changeFrequency: "yearly" },
    { path: "/cookies", priority: 0.3, changeFrequency: "yearly" },
    { path: "/terms", priority: 0.3, changeFrequency: "yearly" },
    { path: "/accessibility", priority: 0.3, changeFrequency: "yearly" },
    { path: "/glossary", priority: 0.5, changeFrequency: "monthly" },
    { path: "/business-lab", priority: 0.6, changeFrequency: "monthly" },
  ];

  /**
   * The five component pages. Each component now lives at its plain-English URL
   * (see src/lib/componentLinks.ts), which is also its landing page, so anything
   * already covered by landingRoutes is dropped here rather than listed twice.
   */
  const componentRoutes: Route[] = aperturePractices
    .map((practice) => componentHref(practice.short))
    .filter((path) => !landingPages.some((l) => l.slug === path))
    .map((path) => ({ path, priority: 0.8, changeFrequency: "monthly" as const }));

  /**
   * The landing pages. Priority 1.0 alongside the homepage, deliberately: each
   * one answers a single question with a single offer, which makes them the
   * pages most worth surfacing.
   */
  const landingRoutes: Route[] = landingPages.map((l) => ({
    path: l.slug,
    priority: 1.0,
    changeFrequency: "monthly" as const,
    lastModified: new Date(`${l.reviewed}T12:00:00Z`),
  }));

  /**
   * The sector pages. Each answers a question in the words that sector's
   * owners use, which is the closest thing on this site to how somebody
   * actually searches.
   */
  const industryRoutes: Route[] = industries.map((i) => ({
    path: i.href,
    priority: 0.9,
    changeFrequency: "monthly" as const,
    lastModified: new Date(`${i.reviewed}T12:00:00Z`),
  }));

  const deliverableRoutes: Route[] = deliverables.map((d) => ({
    path: `/deliverables/${d.slug}`,
    priority: 0.7,
    changeFrequency: "monthly" as const,
  }));

  /**
   * Articles carry their real revision date rather than the build time. A
   * sitemap that stamps every URL with "changed today" on every deploy is not
   * a freshness signal, it is noise, and the pages where the date is actually
   * knowable are the ones where it is worth being accurate.
   */
  const articleRoutes: Route[] = articles.map((a) => ({
    path: `/insights/${a.slug}`,
    priority: 0.6,
    changeFrequency: "monthly" as const,
    lastModified: new Date(`${a.updated ?? a.published}T12:00:00Z`),
  }));

  return [...staticRoutes, ...landingRoutes, ...industryRoutes, ...componentRoutes, ...deliverableRoutes, ...articleRoutes].map((r) => ({
    url: url(r.path),
    lastModified: r.lastModified ?? now,
    changeFrequency: r.changeFrequency,
    priority: r.priority,
  }));
}
