"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { megaNav, primaryCta, siteConfig, type MegaEntry, type MegaLink } from "@/lib/site";
import { Container } from "@/components/ui/Container";
import { Logo } from "@/components/brand/Logo";
import { Menu, ChevronDown } from "@/components/ui/icons";
import { MobileMenu } from "./MobileMenu";
import { AuthBar } from "./AuthBar";
import { LiveClock } from "./LiveClock";
import { cn } from "@/lib/utils";

/**
 * Sticky, two-row site header (Bain-style). A thin utility strip sits above the
 * main bar; grouped nav items open a full-width mega-panel with a left "hub"
 * descriptor box and a column of links. The main bar condenses and turns maroon
 * on scroll (the utility strip collapses away). The mobile trigger opens the
 * full-screen accessible menu (rendered as a sibling so `position: fixed` isn't
 * trapped by the header's backdrop-filter).
 */
export function Header() {
  const pathname = usePathname();
  /*
   * The Method Lab is a separate place with its own header
   * (src/app/method-lab/layout.tsx). The marketing nav has no business in
   * there: it offers a prospect's journey to someone reading internal build
   * notes, and it was why the same Lab material looked like two different
   * systems depending on whether the page was an HTML document or a React page.
   */
  const inMethodLab = pathname === "/method-lab" || pathname.startsWith("/method-lab/");
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mega-panel on route change and on Escape.
  useEffect(() => setOpenGroup(null), [pathname]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpenGroup(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const isActive = useCallback(
    (href: string) =>
      href === "/"
        ? pathname === "/"
        : pathname === href || pathname.startsWith(href + "/"),
    [pathname]
  );

  const closeMobile = useCallback(() => {
    setMobileOpen(false);
    triggerRef.current?.focus();
  }, []);

  // Hover intent: small delay before closing so the pointer can cross the gap
  // between a trigger and its panel.
  const openNow = (label: string) => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpenGroup(label);
  };
  const closeSoon = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpenGroup(null), 120);
  };

  const active = megaNav.find((e) => e.kind === "group" && e.label === openGroup);
  const activeGroup = active && active.kind === "group" ? active : null;

  if (inMethodLab) return null;

  return (
    <>
      <header
        onMouseLeave={closeSoon}
        className={cn(
          "sticky top-0 z-50 border-b backdrop-blur-sm transition-colors duration-300",
          scrolled ? "border-maroon-hover bg-maroon text-paper" : "border-line bg-paper/95 text-ink"
        )}
      >
        {/* Utility strip collapses on scroll */}
        <div
          className={cn(
            "hidden overflow-hidden border-b border-white/10 bg-maroon text-paper transition-all duration-300 lg:block",
            scrolled ? "max-h-0 border-b-0 opacity-0" : "max-h-10 opacity-100"
          )}
        >
          <Container>
            <div className="flex h-9 items-center justify-between gap-6 text-[12px] tracking-[0.01em] text-white/80">
              <span className="whitespace-nowrap">Founder-led · Analytics, AI &amp; strategy for owner-run businesses</span>
              <LiveClock className="whitespace-nowrap text-white/90" />
              <div className="flex items-center gap-5 whitespace-nowrap">
                <a href={`mailto:${siteConfig.email}`} className="hidden transition-colors hover:text-white xl:inline">
                  {siteConfig.email}
                </a>
                <a
                  href="https://www.linkedin.com/in/fenhow"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="LinkedIn"
                  /*
                   * The icon is 15px; the link was too. Padding takes the
                   * touch target to 40px and the negative margin keeps the
                   * icon exactly where it was in the strip.
                   */
                  className="-m-3 inline-flex items-center justify-center p-3 transition-colors hover:text-white"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M20.45 20.45h-3.55v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.55V9h3.57v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z" />
                  </svg>
                </a>
                <AuthBar />
              </div>
            </div>
          </Container>
        </div>

        {/* Main bar */}
        <Container>
          <div
            className={cn(
              "flex items-center justify-between transition-[height] duration-fast",
              scrolled ? "h-16" : "h-20 md:h-[76px]"
            )}
          >
            <Link href="/" aria-label="The Aperture Method, home" className="shrink-0 rounded-sm">
              <Logo
                tone={scrolled ? "light" : "dark"}
                className={cn(
                  "transition-all duration-fast",
                  scrolled ? "text-[clamp(15px,4vw,17px)]" : "text-[clamp(16px,4.4vw,19px)]"
                )}
              />
            </Link>

            {/* Desktop navigation */}
            <nav aria-label="Primary" className="hidden items-center gap-6 lg:flex xl:gap-8">
              {megaNav.map((entry: MegaEntry) =>
                entry.kind === "link" ? (
                  <Link
                    key={entry.href}
                    href={entry.href}
                    aria-current={isActive(entry.href) ? "page" : undefined}
                    onMouseEnter={() => openNow("")}
                    className={cn(
                      "group relative py-1 text-[15px] font-medium transition-colors duration-fast",
                      scrolled ? "text-white/90 hover:text-white" : "text-ink hover:text-maroon"
                    )}
                  >
                    {entry.label}
                    <span
                      className={cn(
                        "absolute -bottom-0.5 left-0 h-0.5 transition-all duration-fast",
                        scrolled ? "bg-white" : "bg-maroon",
                        isActive(entry.href) ? "w-full" : "w-0 group-hover:w-full"
                      )}
                    />
                  </Link>
                ) : (
                  <div
                    key={entry.href}
                    className="relative"
                    onMouseEnter={() => openNow(entry.label)}
                  >
                    <button
                      type="button"
                      aria-haspopup="true"
                      aria-expanded={openGroup === entry.label}
                      onClick={() =>
                        setOpenGroup((v) => (v === entry.label ? null : entry.label))
                      }
                      className={cn(
                        "group relative flex items-center gap-1 py-1 text-[15px] font-medium transition-colors duration-fast",
                        scrolled ? "text-white/90 hover:text-white" : "text-ink hover:text-maroon"
                      )}
                    >
                      {entry.label}
                      <ChevronDown
                        className={cn(
                          "h-3.5 w-3.5 transition-transform duration-fast",
                          openGroup === entry.label && "rotate-180"
                        )}
                      />
                      <span
                        className={cn(
                          "absolute -bottom-0.5 left-0 h-0.5 transition-all duration-fast",
                          scrolled ? "bg-white" : "bg-maroon",
                          isActive(entry.href) || openGroup === entry.label
                            ? "w-full"
                            : "w-0 group-hover:w-full"
                        )}
                      />
                    </button>
                  </div>
                )
              )}
              <Link
                href={primaryCta.href}
                onMouseEnter={() => openNow("")}
                className={cn(
                  "ml-1 rounded-sm px-5 py-2.5 text-sm font-semibold transition-colors duration-fast",
                  // Hovers to black in both header states, so the button
                  // behaves the same whether or not the bar has collapsed.
                  "hover:bg-ink hover:text-paper",
                  scrolled ? "bg-paper text-maroon" : "bg-maroon text-paper"
                )}
              >
                {primaryCta.label}
              </Link>
            </nav>

            {/* Mobile trigger */}
            <button
              ref={triggerRef}
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
              aria-expanded={mobileOpen}
              aria-haspopup="dialog"
              className={cn(
                "rounded-sm p-2 transition-colors duration-fast lg:hidden",
                scrolled ? "text-paper hover:text-white/80" : "text-ink hover:text-maroon"
              )}
            >
              <Menu />
            </button>
          </div>
        </Container>

        {/* Mega-panel (full width, anchored to the header) */}
        {activeGroup && (
          <div
            className="absolute left-0 right-0 top-full hidden border-b border-line bg-paper shadow-subtle lg:block"
            onMouseEnter={() => openNow(activeGroup.label)}
            onMouseLeave={closeSoon}
          >
            <Container>
              <div className="grid grid-cols-[0.9fr_1.5fr] gap-10 py-8">
                {/*
                  Hub descriptor box. `self-start` matters: as a grid child it
                  would otherwise stretch to the height of the tallest link
                  column and leave a lake of empty surface under the blurb.
                */}
                <div className="flex flex-col gap-3 self-start">
                <Link
                  href={activeGroup.hub.href ?? activeGroup.href}
                  className="group flex flex-col rounded-lg bg-surface p-6 transition-colors hover:bg-maroon/[0.06]"
                >
                  <div>
                    <p className="eyebrow mb-3">{activeGroup.hub.eyebrow}</p>
                    <p className="text-h4 font-semibold text-ink">{activeGroup.hub.title}</p>
                    <p className="mt-3 text-small leading-relaxed text-muted">
                      {activeGroup.hub.blurb}
                    </p>
                  </div>
                  <p className="mt-6 text-small font-medium text-maroon">
                    {activeGroup.hub.linkLabel}{" "}
                    <span className="inline-block transition-transform duration-fast group-hover:translate-x-0.5">
                      &rarr;
                    </span>
                  </p>
                </Link>
                {activeGroup.hub.extra ? (
                  <Link
                    href={activeGroup.hub.extra.href}
                    className="group flex items-center justify-between gap-4 rounded-lg border border-maroon px-5 py-3.5 transition-colors hover:bg-maroon"
                  >
                    <span>
                      <span className="block text-body font-semibold text-maroon transition-colors group-hover:text-paper">
                        {activeGroup.hub.extra.label}
                      </span>
                      {activeGroup.hub.extra.note ? (
                        <span className="block text-small text-muted transition-colors group-hover:text-white/80">
                          {activeGroup.hub.extra.note}
                        </span>
                      ) : null}
                    </span>
                    <span aria-hidden="true" className="text-maroon transition-colors group-hover:text-paper">
                      &rarr;
                    </span>
                  </Link>
                ) : null}
                </div>

                {/*
                  Two layouts, chosen by the group.

                  A group with named columns keeps each set together and in its
                  own order, which matters for the five components: flowed
                  across a grid they read 1, 3, 5 down one side and the order
                  disappears. Everything else keeps the original flat grid,
                  where the links are unrelated and the order carries nothing.
                */}
                {activeGroup.columns ? (
                  <div className="grid grid-cols-2 gap-x-8 self-center">
                    {activeGroup.columns.map((col) => (
                      <div key={col.heading}>
                        <p className="mb-2 px-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted">
                          {col.heading}
                        </p>
                        <div className="flex flex-col gap-y-1">
                          {col.links.map((l) => (
                            <MegaPanelLink key={l.href} link={l} current={isActive(l.href)} />
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-x-8 gap-y-1 self-center">
                    {activeGroup.links.map((l) => (
                      <MegaPanelLink key={l.href} link={l} current={isActive(l.href)} />
                    ))}
                  </div>
                )}
              </div>
            </Container>
          </div>
        )}
      </header>

      <MobileMenu open={mobileOpen} onClose={closeMobile} isActive={isActive} />
    </>
  );
}

/**
 * One row in a mega panel. Pulled out of the panel because the panel now has
 * two ways of laying rows out, and the row itself should not care which.
 */
function MegaPanelLink({ link, current }: { link: MegaLink; current: boolean }) {
  const inner = (
    <>
      <span className="flex items-baseline gap-2">
        {link.step && (
          <span className="text-[11px] font-semibold tabular-nums text-maroon">{link.step}</span>
        )}
        <span className="text-[15px] font-semibold text-ink group-hover:text-maroon">
          {link.label}
        </span>
        {link.step && (
          <span
            className="ml-auto self-center text-maroon opacity-40 transition-all duration-fast group-hover:translate-x-0.5 group-hover:opacity-100"
            aria-hidden="true"
          >
            &rarr;
          </span>
        )}
      </span>
      {link.desc && (
        <span className={cn("mt-0.5 block text-small text-muted", link.step && "pl-[26px]")}>
          {link.desc}
        </span>
      )}
    </>
  );
  const cls = "group block rounded-md px-3 py-2.5 transition-colors hover:bg-surface";

  return link.external ? (
    <a href={link.href} target="_blank" rel="noopener noreferrer" className={cls}>
      {inner}
    </a>
  ) : (
    <Link href={link.href} aria-current={current ? "page" : undefined} className={cls}>
      {inner}
    </Link>
  );
}
