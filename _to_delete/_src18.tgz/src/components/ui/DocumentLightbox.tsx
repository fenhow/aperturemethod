"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

/**
 * A link that opens a PDF in a new tab, at the right page.
 *
 * This used to open a full-screen in-app viewer with an "open in a new tab"
 * fallback inside it. It now goes straight to the new tab, by request, and the
 * reasons are good ones: the browser's own PDF viewer handles paging, search,
 * zoom, printing and saving better than an iframe can, it does not trap a
 * reader inside a modal, and on iOS Safari an embedded PDF frequently refuses
 * to render at all, which turned the most important proof link on the site
 * into a blank rectangle on a phone.
 *
 * The name is kept, and so is the signature, so every call site is unchanged.
 * The Viewer below is no longer reachable; it is left in place, unexported, for
 * the moment someone wants the modal back on a specific page.
 */
export function DocumentLightbox({
  href,
  title,
  triggerLabel,
  triggerClassName,
  triggerIcon = true,
  page,
}: {
  href: string;
  title: string;
  triggerLabel: React.ReactNode;
  triggerClassName?: string;
  triggerIcon?: boolean;
  /** Optional starting page in the PDF (1-indexed). */
  page?: number;
}) {
  const target = page ? `${href}#page=${page}` : `${href}#view=FitH`;

  return (
    <>
      <a
        href={target}
        target="_blank"
        rel="noopener noreferrer"
        className={triggerClassName}
      >
        {triggerIcon && (
          <svg
            className="h-4 w-4 shrink-0"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.7"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            {/* document with a folded corner (PDF) */}
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            <path d="M14 2v6h6" />
            <path d="M8.5 13.5h7M8.5 17h4.5" />
          </svg>
        )}
        {triggerLabel}
        <span className="sr-only"> (opens in a new tab)</span>
      </a>
    </>
  );
}

function Viewer({
  src,
  href,
  title,
  onClose,
}: {
  src: string;
  href: string;
  title: string;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    // Capture phase + stopImmediatePropagation so Escape closes only this
    // viewer, leaving any modal beneath it (e.g. a deliverable popup) open.
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopImmediatePropagation();
        onClose();
      }
    };
    document.addEventListener("keydown", onKey, true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey, true);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[120] flex flex-col bg-ink/90 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div className="flex items-center justify-between gap-4 px-4 py-3 text-paper sm:px-6">
        <p className="min-w-0 flex-1 truncate text-small font-semibold text-paper">{title}</p>
        <div className="flex items-center gap-2">
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-sm border border-white/25 px-3 py-1.5 text-small font-medium text-white/90 transition-colors hover:bg-white/10"
          >
            Open in new tab
            <span aria-hidden="true">↗</span>
          </a>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close document"
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-white/25 text-paper transition-colors hover:bg-white/10"
          >
            ✕
          </button>
        </div>
      </div>
      <div className="min-h-0 flex-1 px-2 pb-2 sm:px-4 sm:pb-4">
        <iframe
          src={src}
          title={title}
          className="h-full w-full rounded-lg border border-white/10 bg-white"
        />
      </div>
    </div>,
    document.body
  );
}
