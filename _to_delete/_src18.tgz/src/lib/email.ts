import "server-only";
import nodemailer, { type Transporter } from "nodemailer";

/**
 * Transactional email over SMTP, sent from your own mailbox (e.g. Google
 * Workspace / Gmail on aperturemethod.com). No third-party service. Set these in
 * Vercel → Settings → Environment Variables (Server):
 *
 *   SMTP_HOST  : e.g. smtp.gmail.com
 *   SMTP_PORT  : 465 (SSL) or 587 (STARTTLS). Default 587.
 *   SMTP_SECURE: "true" for port 465, otherwise leave unset/"false".
 *   SMTP_USER  : the full mailbox address (e.g. hello@aperturemethod.com)
 *   SMTP_PASS  : an app password for that mailbox (not your login password)
 *   ONBOARDING_FROM_EMAIL  : optional display sender; defaults to SMTP_USER
 *   ONBOARDING_NOTIFY_EMAIL: where owner notifications go; defaults to SMTP_USER
 *
 * Until SMTP is configured, sends are logged and treated as best-effort so the
 * rest of the flow (PDF + portal storage) still works.
 */
const SMTP_HOST = (process.env.SMTP_HOST ?? "").trim();
const SMTP_PORT = Number(process.env.SMTP_PORT ?? "587");
const SMTP_SECURE = (process.env.SMTP_SECURE ?? "").trim().toLowerCase() === "true";
const SMTP_USER = (process.env.SMTP_USER ?? "").trim();
const SMTP_PASS = (process.env.SMTP_PASS ?? "").trim();

export const FROM_EMAIL =
  (process.env.ONBOARDING_FROM_EMAIL ?? "").trim() ||
  (SMTP_USER ? `The Aperture Method <${SMTP_USER}>` : "The Aperture Method <hello@aperturemethod.com>");
export const NOTIFY_EMAIL =
  (process.env.ONBOARDING_NOTIFY_EMAIL ?? "").trim() || SMTP_USER || "hello@aperturemethod.com";

export const emailConfigured = Boolean(SMTP_HOST && SMTP_USER && SMTP_PASS);

let transporter: Transporter | null = null;
function getTransport(): Transporter {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: SMTP_SECURE,
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
  }
  return transporter;
}

/**
 * A file on a message.
 *
 * `cid` makes it INLINE rather than a download: the HTML references it as
 * <img src="cid:the-id">, and nodemailer marks the part inline so clients
 * render it in place instead of listing it beside the real attachments. That
 * is how a signature image reaches the reader without depending on a remote
 * fetch, which most clients block by default on a first message from an
 * unknown sender.
 */
export type Attachment = {
  filename: string;
  contentBase64: string;
  /** Set to embed the file in the body rather than attach it. */
  cid?: string;
  contentType?: string;
};

export async function sendEmail(opts: {
  to: string | string[];
  subject: string;
  html: string;
  replyTo?: string;
  attachments?: Attachment[];
}): Promise<{ ok: boolean; error?: string }> {
  if (!emailConfigured) {
    console.info("[email] (SMTP not configured) would send:", opts.subject, "→", opts.to);
    return { ok: false, error: "not-configured" };
  }
  try {
    await getTransport().sendMail({
      from: FROM_EMAIL,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      replyTo: opts.replyTo,
      attachments: opts.attachments?.map((a) => ({
        filename: a.filename,
        content: Buffer.from(a.contentBase64, "base64"),
        ...(a.cid ? { cid: a.cid, contentDisposition: "inline" as const } : {}),
        /*
         * Oct 2026: a hardcoded contentType: "application/pdf" used to sit
         * here, AFTER the spread, so it won for every attachment. The inline
         * signature PNG went out labelled as a PDF and every mail client drew
         * a broken-image box in its place. Each attachment now carries its own
         * type, and anything without one (the report PDF) is inferred by
         * nodemailer from the filename.
         */
        ...(a.contentType ? { contentType: a.contentType } : {}),
      })),
    });
    return { ok: true };
  } catch (err) {
    console.error("[email] SMTP send failed", err);
    return { ok: false, error: "smtp-exception" };
  }
}
